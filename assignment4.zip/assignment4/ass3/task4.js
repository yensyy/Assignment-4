function BMI_Calculator(weight, height)
        {
            var BMI = (weight) / (height/100 * height/100);

            if (BMI<18.5){
            alert("Your BMI is " + BMI + ", so you are " + "Underweight");
            } else if (BMI>=18.5 && BMI<=24.9){
            alert("Your BMI is " + BMI + ", so you are " + "Normal");
            } else if (BMI>=25 && BMI<=29.9){
            alert("Your BMI is " + BMI + ", so you are " + "Overweight");
            } else if (BMI>30 && BMI<=34.9) {
            alert("Your BMI is " + BMI + ", so you are " + "Obese");
            } else if (BMI>35){
            alert("Your BMI is " + BMI + ", so you are " + "Extremely Obese");
            }
        }
        BMI_Calculator(weight, height);
